<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Add Product</title>
</head>
<body>
    <div class="container">
        <h1 class="text-center" >Update Data</h1>
        <form method="POST" action="/update/{{$products->id}}">
        @csrf
            <div class="mb-3">
                <label><b>Product Name</b></label>
                <input type="text" name="name" class="form-control" value={{$products->name}}>
            </div>
            <div class="mb-3">
                <label><b>Price</b></label>
                <input type="text" name="price" class="form-control" value={{$products->price}}> 
            </div>
            <div class="mb-3">
                <label><b>Image</b></label>
                <input type="file" name="image" class="form-control" value={{$products->image}}>
            </div>
            <div class="mb-3">
                <label><b>Description</b></label>
                <textarea type="text" name="description" class="form-control" value={{$products->description}}></textarea>
            </div>
            <input type="submit" name="update" value="update" class="btn btn-success">
        </form>
    </div>
</body>
</html>