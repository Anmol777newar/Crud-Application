<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use DB;


class ProductController extends Controller
{
    public function index(){
        return view('add-product');
    }

    public function store(Request $request){
        $product=new Product;
        $product->name=$request->get('name');
        $product->price=$request->get('price');
        $product->image=$request->get('image');
        $product->description=$request->get('description');
        $product->save();

        echo "<h1>Data send successfully</h1>";
    }

    public function show(Product $product){
        $products=Product::all();
        return view('show',['products'=>$products]);
    }

    public function delete(Product $product,$id){
        $product=Product::find($id);
        $product->delete();
        return redirect('show');
    }

    public function edit(Product $product,$id){
        $products=Product::find($id);
        return view('edit',['products'=>$products]);
    }

    public function update(Request $request, Product $product,$id){
        $product=Product::find($id);
        $product->name=$request->get('name');
        $product->price=$request->get('price');
        $product->image=$request->get('image');
        $product->description=$request->get('description');

        $product->save();
        return redirect('show');

    }

}
